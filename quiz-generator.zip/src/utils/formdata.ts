export const count = ['1', '2', '3', '4', '5']

export const type = ["MCQs", "True-False"]

export const difficulty = ["Easy", "Medium", "Hard"]