import { count, difficulty, type } from '@/utils/formdata'
import { IssueData, z } from 'zod'

export const signUpSchema = z.object({
    name: z.string().min(1, "Name is required").max(20, "User name can not be more than 20 letters"),
    email: z.string().min(1, "Email is required").email({ message: "Must be a valid email" }),
    password: z.string().min(8, "Password must be at least 8 characters")
})



export const signInSchema = z.object({
    email: z.string().min(1, "Email is required").email({ message: "Must be a valid email" }),
    password: z.string().min(8, "Password must be at least 8 characters")
})

export const generateQuizSchema = z.object({
    content: z.string().min(1,"Content is required").max(13000,"Content can not be more than 13000 letters"),
    type: z.string().superRefine((val, ctx) => {
        if (!type.includes(val)) {
            ctx.addIssue({
                code: z.ZodIssueCode.custom,
                message: 'Quiz type should be valid',
                fatal: true
            })
            return z.NEVER
        }
    }),
    count: z.string().superRefine((val, ctx) => {
        if (!count.includes(val)) {
            ctx.addIssue({
                code: z.ZodIssueCode.custom,
                message: 'Quiz count should be valid',
            })
        }
    }),
    difficulty: z.string().superRefine((val, ctx) => {
        if (!difficulty.includes(val)) {
            ctx.addIssue({
                code: z.ZodIssueCode.custom,
                message: 'Quiz difficulty should be valid',
            })
        }
    }),
})


export type ISignUpSchema = z.infer<typeof signUpSchema>


export type ISignInSchema = z.infer<typeof signInSchema>


export type IGenerateQuizSchema = z.infer<typeof generateQuizSchema>

