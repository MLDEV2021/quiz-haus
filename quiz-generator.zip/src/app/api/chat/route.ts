import { connect } from "@/db";
import User from "@/db/models/users";
import { IGenerateQuizSchema, generateQuizSchema } from "@/lib/zodSchema";
import { NextRequest, NextResponse } from "next/server";
import OpenAI from "openai";

export const POST = async (request: NextRequest) => {
    const openai = new OpenAI();

    try {
        await connect()
        const verifiedJwt = JSON.parse(request.headers.get('verifiedJwt')!)
        let user = await User.findOne({ _id: verifiedJwt.id })
        if (user.freeTurns <= 0 && !user.purchased) {
            return NextResponse.json({ status: 'error', message: 'Free trail ended' }, { status: 429 })
        }

        const body: IGenerateQuizSchema = await request.json()
        let result = generateQuizSchema.safeParse(body)
        if (!result.success) {
            let zodErrors = {}
            result.error.issues.forEach((issue) => {
                zodErrors = { ...zodErrors, [issue.path[0]]: issue.message }
            })
            return NextResponse.json({ errors: zodErrors, status: 'error' }, { status: 400 })
        }

        const type = body.type === 'MCQs' ? 'MCQs (Multiple Choice Questions)' : body.type
        const finalPrompt = `
Please generate a quiz that consists of ${body.count} ${body.type} questions.
The difficulty level of questions should be ${body.difficulty}.
And remember one thing that The number of questions must be ${body.count} and question must be of type ${body.type}.
Question format should be like this:

Q{Question number}: Question ?
a) Option 1
b) Option 2
c) Option 3
d) Option 4
Correct Answer: {Option}) Answer
....
....
....

Now, based on the following text, generate the questions for the quiz:

///${body.content}///
`
        const data = await openai.chat.completions.create({
            messages: [{ role: "user", content: finalPrompt }],
            model: "gpt-3.5-turbo",
        });
        // const res = await fetch('https://api.openai.com/v1/completions', {
        //     method: 'POST',
        //     headers: {
        //         Authorization: `Bearer ${process.env.OPENAI_API_KEY}`,
        //         "Content-Type": "application/json"
        //     },
        //     body: JSON.stringify({
        //         model: 'gpt-3.5-turbo',
        //         messages: [{ role: "user", content: finalPrompt }],
        //         // prompt: finalPrompt,
        //         max_tokens: 500,
        //     })
        // })
        // const data = await res.json()

        // if (!data.choices[0].text) {
        //     throw new Error('error')
        // }
        if (!user.purchased) {
            await User.findOneAndUpdate({ _id: verifiedJwt.id }, { freeTurns: user.freeTurns - 1 })
        }
        return NextResponse.json({ status: 'success', data: data.choices[0].message.content })
    }
    catch (err: any) {
        return NextResponse.json({ status: 'error', message: err.message }, { status: 500 })
    }
}




