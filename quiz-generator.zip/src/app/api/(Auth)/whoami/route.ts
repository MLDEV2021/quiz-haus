import User from "@/db/models/users";
import { NextRequest, NextResponse } from "next/server";

export const GET = async (request: NextRequest) => {
    let details = JSON.parse(request.headers.get('verifiedJwt') as string)
    if (!details) {
        return NextResponse.json({ status: 'error', message: 'Unauthorized' }, { status: 403 })
    }
    const user = await User.findOne({ _id: details.id })
    const userDetails = {
        id: user._id, name: user.name, email: user.email, purchased: user.purchased
    }
    return NextResponse.json({ userDetails }, { status: 200 })
}