'use client'

import { IGenerateQuizSchema, generateQuizSchema } from '@/lib/zodSchema';
import { zodResolver } from '@hookform/resolvers/zod';
import React, { ChangeEvent, useContext, useState } from 'react';
import { AiOutlineCloudUpload } from 'react-icons/ai'
import { useForm } from 'react-hook-form'
import { count, difficulty, type } from '@/utils/formdata';
import { saveAs } from 'file-saver';
import { PDFDocument, StandardFonts, rgb } from 'pdf-lib'
import Script from 'next/script';
import { Loader } from '@/components/common';
import { ContextApi } from '@/context/context';


function Dashboard() {
    const [pdfText, setPdfText] = useState('');
    const [loading, setLoading] = useState(false);
    const [file, setFile] = useState<File>();
    const [quizLoading, setQuizLoading] = useState(false);
    const [checkoutLoading, setCheckoutLoading] = useState(false);
    const [quizData, setQuizData] = useState('')
    const [quizDataPopUp, setQuizDataPopUp] = useState(false)
    const [purchasePopUp, setPurchasePopUp] = useState(false)

    const { state, dispatch } = useContext(ContextApi)
    const {
        register,
        handleSubmit,
        reset,
        setValue,
        setError,
        formState: {
            errors,
            isSubmitting
        },
    } = useForm<IGenerateQuizSchema>({
        resolver: zodResolver(generateQuizSchema)
    })

    const uploadPDF = (e: ChangeEvent<HTMLInputElement>) => {
        const file = e?.target?.files![0]
        if (!file) return
        console.log(file.type);

        if (file.type !== 'application/pdf') {
            alert('Please Upload a PDF file')
            return
        }
        // setPdfText('')
        let fr = new FileReader()
        fr.readAsDataURL(file)
        fr.onload = () => {
            setFile(file)
            setError('content', { message: '' })
            extractText(fr.result)
        }
    }

    async function extractText(url: any) {
        setLoading(true)
        let alltext: any[] = []
        try {
            // @ts-ignore
            let pdf = await pdfjsLib.getDocument(url).promise; // Get the PDF document without password

            let pages = pdf.numPages; // Get the total number of pages in the PDF
            for (let i = 1; i <= pages; i++) {
                let page = await pdf.getPage(i); // Get the page object for each page
                let txt = await page.getTextContent(); // Get the text content of the page
                // console.log((await page.getTextContent()).styles);
                let text = txt.items.map((s: any) => s.str).join(""); // Concatenate the text items into a single string
                alltext.push(text); // Add the extracted text to the array
            }
            console.log(alltext);
            setValue('content', alltext.map((page) => `${page}\n\n`).join(' '))
            setPdfText(alltext.map((page) => `${page}\n\n`).join(' '))

        } catch (err: any) {
            alert(err.message);
        }
        finally {
            setLoading(false)
        }
    }




    async function GenerateQuiz(config_data: IGenerateQuizSchema) {
        console.log(config_data);
        try {
            setQuizLoading(true)
            const res = await fetch('/api/chat', {
                method: 'POST',
                body: JSON.stringify({
                    content: config_data.content,
                    type: config_data.type,
                    count: config_data.count,
                    difficulty: config_data.difficulty
                })
            })
            if (res.status === 429) {
                dispatch({ type: 'TOGGLE_CHECKOUT_POPUP', payload: true })
                // setPurchasePopUp(true)
                return
            }
            const { data } = await res.json()
            setQuizData(data)
        }
        catch (err) {
            console.log(err);
        }
        finally {
            setQuizLoading(false)
        }
    }


    function addNewlineAfter5Words(inputString: any) {
        inputString = inputString.split('\n')
        for (let i = 0; i < inputString.length; i++) {
            let innerText = inputString[i].split('')
            for (let j = 0; j < innerText.length; j++) {
                if (j % 89 === 0 && j !== 0) {
                    for (let k = 1; k < 30; k++) {
                        if (innerText[j + k] === ' ') {
                            innerText.splice(j + k, 0, '\n')
                            break;
                        }
                    }
                }
            }
            inputString[i] = innerText.join('')
        }
        return inputString.join('\n');
    }


    async function GenerateAndDownloadPDF(data: string) {
        const pdfDoc = await PDFDocument.create()
        const timesRomanFont = await pdfDoc.embedFont(StandardFonts.TimesRoman)
        const page = pdfDoc.addPage([600, 1200])
        const { width, height } = page.getSize()
        const fontSize = 12
        page.drawText(addNewlineAfter5Words(data), {
            x: 30,
            y: height - 3 * fontSize,
            size: fontSize,
            font: timesRomanFont,
            color: rgb(0, 0, 0),
        })
        const pdfBytes = await pdfDoc.save()

        console.log(data);
        const file = new Blob([pdfBytes], { type: 'application/pdf' });
        saveAs(file, 'quiz-file.pdf');
    }


    async function CheckOut() {
        try {
            setCheckoutLoading(true)
            const res = await fetch("/api/payment", {
                method: "POST",
                body: JSON.stringify({}),
                headers: {
                    "Content-Type": "application/json"
                }
            });
            const data = await res.json()
            console.log(data)
            if (data.url) {
                window.location.assign(data.url)
            }
        }
        catch (err: any) {
            console.log(err);
        }
        finally {
            setCheckoutLoading(false)
        }
    }

    return (
        <div className='bg-[#f5f5f5] w-full min-h-screen py-10'>
            <Script src="https://npmcdn.com/pdfjs-dist@3.11.174/build/pdf.js" ></Script>

            {
                quizDataPopUp &&
                <div className='fixed top-0 left-0 w-screen h-screen flex justify-center items-center bg-[rgba(0,0,0,0.3)] backdrop-blur-sm'>
                    <div className='w-[90%] md:w-[700px] h-[90vh] flex flex-col bg-white px-5 pt-5'>
                        <textarea name="" id="" value={quizData} onChange={(e) => setQuizData(e.target.value)} cols={30} rows={10} className='text-sm md:text-base outline-none flex-grow'></textarea>
                        <div className='py-5 flex gap-5 border-t'>
                            <button className='py-2 px-5 tracking-wider text-sm text-white font-semibold border-2 border-primary bg-primary rounded-lg' onClick={() => GenerateAndDownloadPDF(quizData)}>Download PDF</button>
                            <button className='py-2 px-5 tracking-wider text-sm font-semibold border-2 border-primary rounded-lg' onClick={() => setQuizDataPopUp(false)}>Close</button>
                        </div>
                    </div>
                </div >
            }
            {
                state.checkOutPopUp &&
                <div className='fixed top-0 left-0 w-screen h-screen flex justify-center items-center bg-[rgba(0,0,0,0.3)] backdrop-blur-sm'>
                    <div className='w-[90%] md:w-[500px] flex flex-col bg-white px-5 pt-5'>
                        <div className='mb-10'>
                            <h1 className='text-2xl font-extrabold text-zinc-800'>Monthly Plan</h1>
                            <h1 className='text-lg font-extrabold text-zinc-800 mt-10'><span className='text-4xl'>$20</span> / Month</h1>
                            <button onClick={() => checkoutLoading ? false : CheckOut()} disabled={checkoutLoading} className='font-extrabold text-white [word-spacing:5px] flex justify-center items-center h-[50px] w-[300px] rounded-lg bg-primary mt-10'>{checkoutLoading ? <Loader height='h-4' width='w-4' /> : 'Proceed to Payment'} </button>
                        </div>
                        <div className='py-5 flex gap-5 border-t'>
                            <button className='py-2 px-5 tracking-wider text-sm font-semibold border-2 border-primary rounded-lg' onClick={() => dispatch({ type: 'TOGGLE_CHECKOUT_POPUP', payload: false })}>Close</button>
                        </div>
                    </div>
                </div >
            }
            <div>
                <div className='w-[90%] lg:w-[800px] m-auto rounded-lg p-5'>
                    <label htmlFor="pdf" className='w-full border border-dashed border-zinc-600 cursor-pointer rounded-lg h-[70px] bg-zinc-200 flex justify-center items-center'>
                        <div className='flex gap-5 items-center'>
                            {
                                !loading ?
                                    <>
                                        <h1 className='text-lg font-extrabold text-zinc-800'>Upload PDF</h1>
                                        <AiOutlineCloudUpload className='text-4xl text-primary' />
                                    </>
                                    :
                                    <h1 className='text-lg font-extrabold text-zinc-800'>Uploading ...</h1>
                            }
                        </div>
                        <input hidden onChange={uploadPDF} type="file" name="pdf" id="pdf" />
                    </label>
                    <form onSubmit={handleSubmit(GenerateQuiz)}>
                        <div className='w-full h-[280px] text-sm p-3 rounded-3xl mt-5 bg-white shadow-[0_0_20px_rgba(0,0,0,0.1)]'>
                            {
                                !pdfText ?
                                    <div className='w-full h-full flex justify-center items-center'>
                                        <h1 className='text-lg text-zinc-800 font-extrabold [word-spacing:3px]'>No PDF Uploaded</h1>
                                    </div>
                                    :
                                    <textarea {...register("content")} className='w-full h-full resize-none outline-none'></textarea>
                            }
                        </div>
                        {
                            errors.content && <p className='text-red-500 text-sm mt-2'>{file ? errors.content.message : 'Upload a PDF file'}</p>
                        }
                        <div className='mt-5 grid grid-cols-1 md:grid-cols-3 gap-5 mb-5'>
                            <div>
                                <label htmlFor="type" className='text-sm font-bold text-[#26292E]'>Select Quiz Type</label>
                                <select id="type" {...register("type")} className={`text-sm outline-none w-full py-3 px-5 rounded-xl bg-white shadow-[0_0_20px_rgba(0,0,0,0.1)] mt-1`}>
                                    {
                                        type.map((item, index) => <option value={item} key={index}>{item}</option>)
                                    }
                                </select>
                                {
                                    errors.type && <p className='text-red-500 text-sm'>{errors.type.message}</p>
                                }
                            </div>
                            <div>
                                <label htmlFor="count" className='text-sm font-bold text-[#26292E]'>Question Count</label>
                                <select id="count" {...register("count")} className={`text-sm outline-none w-full py-3 px-5 rounded-xl bg-white shadow-[0_0_20px_rgba(0,0,0,0.1)] mt-1`}>
                                    {
                                        count.map((item, index) => <option value={item} key={index}>{item}</option>)
                                    }
                                </select>
                                {
                                    errors.count && <p className='text-red-500 text-sm'>{errors.count.message}</p>
                                }
                            </div>
                            <div>
                                <label htmlFor="type" className='text-sm font-bold text-[#26292E]'>Select Difficulty Level</label>
                                <select id="type" {...register("difficulty")} className={`text-sm outline-none w-full py-3 px-5 rounded-xl bg-white shadow-[0_0_20px_rgba(0,0,0,0.1)] mt-1`}>
                                    {
                                        difficulty.map((item, index) => <option value={item} key={index}>{item}</option>)
                                    }
                                </select>
                                {
                                    errors.difficulty && <p className='text-red-500 text-sm'>{errors.difficulty.message}</p>
                                }
                            </div>
                        </div>
                        <button type={quizLoading ? 'button' : 'submit'} className='w-full py-3 bg-primary rounded-lg text-white font-semibold text-center'>{quizLoading ? 'Generating Quiz ...' : 'Generate Quiz'}</button>
                        {
                            quizData &&
                            <p className='text-sm md:text-base text-zinc-800 mt-3'>Quiz generated successfully. <span className='text-primary underline cursor-pointer' onClick={() => setQuizDataPopUp(true)}>Click Here</span> to view Quiz</p>
                        }
                        {/* <button type='button' className='w-full py-3 bg-green-400 mt-5 rounded-lg text-white font-semibold text-center'>View Quiz</button> */}
                    </form>
                </div>
            </div>
        </div>

    );
}

export default Dashboard