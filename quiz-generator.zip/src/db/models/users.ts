import mongoose, { Schema } from "mongoose";

const User = new Schema({
    name: {
        type: String,
    },
    email: {
        type: String,
    },
    password: {
        type: String,
    },
    purchased: {
        type: Boolean,
        default: false
    },
    freeTurns: {
        type: Number,
        default: 3
    }

})

export default mongoose.models.User || mongoose.model('User', User)                                                                                                                                                                                                                                                     