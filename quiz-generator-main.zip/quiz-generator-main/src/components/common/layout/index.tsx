import React, { ReactNode } from 'react';

function Layout({ children }: { children: ReactNode }) {
    return (
        <div className='w-[90%] 2xl:w-[1400px] mx-auto'>
            {children}
        </div>
    );
}

export default Layout;