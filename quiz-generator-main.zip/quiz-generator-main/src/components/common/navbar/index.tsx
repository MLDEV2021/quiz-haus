'use client'
import { ContextApi } from '@/context/context';
import React, { useContext } from 'react';
import Layout from '../layout';
import Link from 'next/link';
import Image from 'next/image';
import { FiLogOut } from 'react-icons/fi'
import {
    Menu,
    MenuButton,
    MenuList,
    MenuItemOption,
    MenuOptionGroup,
    MenuDivider,
} from '@chakra-ui/react'

function Navbar() {
    const { state, dispatch, Logout } = useContext(ContextApi)
    console.log(state);

    return (
        <div className='w-full py-5 bg-transparent border-b sticky top-0 z-[100]'>
            <Layout>
                <div className='flex justify-between items-center'>
                    {/* <h1>LOGO</h1> */}
                    <Image src={'/logo.png'} alt='logo' width={160} height={43} className='w-[100px] md:w-[140px]' />
                    <ul className='text-sm text-zinc-800 flex items-center gap-5 md:gap-10'>
                        <li><Link href={'/'}>Home</Link></li>
                        {
                            state.loading ? <li>loading...</li>
                                :
                                state.userDetails ?
                                    <>
                                        <li><Link href={'/dashboard'}>dashboard</Link></li>
                                        {/* <li onClick={Logout} className='cursor-pointer'>logout</li> */}
                                        <div className='flex items-center gap-3'>
                                            <div className='hidden md:block'>
                                                {
                                                    state.userDetails.purchased ?
                                                        <button className='text-sm font-bold bg-green-300 py-2 px-5 rounded-lg'>Purchased</button>
                                                        :
                                                        <button onClick={() => dispatch({ type: 'TOGGLE_CHECKOUT_POPUP', payload: true })} className='text-sm font-bold bg-gray-300 py-2 px-5 rounded-lg'>Buy</button>
                                                }
                                            </div>
                                            <div className='border-l border-zinc-400 h-[20px]'></div>
                                            <Menu closeOnSelect={false}>
                                                <MenuButton className='text-xl font-bold w-[35px] h-[35px] flex justify-center items-center rounded-full uppercase bg-orange-400'>
                                                    {state.userDetails.name[0]}
                                                </MenuButton>
                                                <MenuList width='240px' className='mt-5 bg-white shadow-lg'>
                                                    <div className='py-2 px-4'>
                                                        <h1 className='text-xl text-zinc-800 font-bold capitalize'>{state.userDetails.name}</h1>
                                                        <p className='text-xs font-semibold text-zinc-600'>{state.userDetails.email}</p>
                                                        <div className='mt-3'>
                                                            {
                                                                state.userDetails.purchased ?
                                                                    <button className='text-sm font-bold bg-green-300 py-2 px-5 rounded-lg'>Purchased</button>
                                                                    :
                                                                    <button onClick={() => dispatch({ type: 'TOGGLE_CHECKOUT_POPUP', payload: true })} className='text-sm font-bold bg-gray-300 py-2 px-5 rounded-lg'>Buy</button>
                                                            }
                                                        </div>
                                                        <div className='border-t my-4 w-full'></div>
                                                        <div onClick={Logout} className='flex items-center gap-3 cursor-pointer'>
                                                            <div className='w-[40px] h-[40px] flex justify-center items-center rounded-full bg-zinc-200'>
                                                                <FiLogOut className='text-lg' />
                                                            </div>
                                                            <h3 className='text-zinc-800 font-bold'>Log Out</h3>
                                                        </div>
                                                    </div>
                                                </MenuList>
                                            </Menu>
                                        </div>
                                    </>
                                    :
                                    <li><Link href={'/signup'}>Register</Link></li>
                        }
                    </ul>
                </div>
            </Layout>
        </div>
    );
}

export default Navbar;