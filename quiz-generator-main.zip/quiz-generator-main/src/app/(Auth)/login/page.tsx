'use client'

import { Loader } from '@/components/common';
import Link from 'next/link';
import React, { ChangeEvent, FormEvent, useContext, useState } from 'react';
import { Toaster, toast } from 'react-hot-toast';
// import Cookies from 'js-cookie';
import { useRouter } from 'next/navigation';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod'
import { ISignInSchema, signInSchema } from '@/lib/zodSchema';
import { ContextApi } from '@/context/context';

function SignUp() {

    const [loading, setLoading] = useState(false)

    const {
        register,
        handleSubmit,
        reset,
        formState: { errors, isSubmitting },
    } = useForm<ISignInSchema>({
        resolver: zodResolver(signInSchema)
    })

    const router = useRouter()
    const { state, dispatch, Logout } = useContext(ContextApi)

    async function onSubmit(data: ISignInSchema) {
        try {
            setLoading(true)
            const response = await fetch('/api/login', {
                method: 'POST',
                headers: {
                    'Content-type': 'application/json',
                },
                body: JSON.stringify(data)
            })
            const resData = await response.json()
            if (resData.status === 'error') {
                throw new Error(resData.message)
            }
            if (resData.status === 'success') {
                console.log("resData.role === >>> ", resData.data);
                dispatch({ type: 'LOGIN', payload: resData.data })
                location.reload()
            }
        }
        catch (err: any) {
            setLoading(false)
            toast.error(err.message, {
                duration: 3000,
                position: window.matchMedia("(min-width: 600px)").matches ? "bottom-right" : "bottom-center",

                style: {
                    backgroundColor: '#d9d9d9',
                    padding: window.matchMedia("(min-width: 600px)").matches ? "20px 30px" : "15px 20px",
                    fontSize: '14px',
                    fontWeight: 'bold'
                },
            });
        }
    }



    return (
        <div className=''>
            {
                loading &&
                <div className='absolute top-0 left-0 w-full h-full bg-[rgba(255,255,255,0.4)] backdrop-blur-sm flex justify-center items-center'>
                    <Loader height='h-8' width='w-8' />
                </div>
            }
            <Toaster />
            <div className='w-[90%] md:w-[600px] rounded-md mx-auto px-5 py-5 mt-16 md:mt-28 shadow-[0_0_10px_rgba(0,0,0,0.3)]'>

                <form onSubmit={handleSubmit(onSubmit)} className='flex flex-col gap-5 mt-7'>
                    <input {...register("email")} type='email' placeholder='Email address' className={`text-sm ${errors.email && 'border border-red-500'} outline-none w-full py-4 px-5 rounded-md border border-zinc-300`} />
                    {
                        errors.email && <p className='text-sm text-red-500 -mt-4'>{errors.email.message}</p>
                    }
                    <input {...register("password")} type="password" placeholder='Password' className={`text-sm ${errors.password && 'border border-red-500'} outline-none w-full py-4 px-5 rounded-md border border-zinc-300`} />
                    {
                        errors.password && <p className='text-sm text-red-500 -mt-4'>{errors.password.message}</p>
                    }
                    {
                        loading ?
                            <button type='button' className='text-white bg-primary font-bold rounded-md tracking-widest w-full h-[50px] text-center'>LOGIN</button>
                            :
                            <button type='submit' className='text-white bg-primary font-bold rounded-md tracking-widest w-full h-[50px] text-center'>LOGIN</button>
                    }
                    <div className='mt-3 py-3 border-t'>
                        <p className='text-sm text-main_dark'>Don&apos;t have an account? <Link href={'/signup'} className='text-blue-700' >signup</Link></p>
                    </div>
                </form>

            </div>
        </div>

    );
}




export default SignUp;