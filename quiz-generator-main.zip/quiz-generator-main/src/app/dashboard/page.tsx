'use client'

import { IGenerateQuizSchema, generateQuizSchema } from '@/lib/zodSchema';
import { zodResolver } from '@hookform/resolvers/zod';
import React, { ChangeEvent, useContext, useState } from 'react';
import { AiOutlineCloudUpload } from 'react-icons/ai'
import { useForm } from 'react-hook-form'
import { count, difficulty, type } from '@/utils/formdata';
import { saveAs } from 'file-saver';
import { PDFDocument, StandardFonts, rgb } from 'pdf-lib'
import Script from 'next/script';
import { Loader } from '@/components/common';
import { ContextApi } from '@/context/context';
import Image from 'next/image';
import { TbTrash } from "react-icons/tb";
import { jsPDF } from "jspdf";
import { IoMenu } from "react-icons/io5";
import { FiLogOut } from 'react-icons/fi';


interface QuizQuestion {
    question: string;
    options: string[];
    correct: string;
}


function Dashboard() {
    const [pdfText, setPdfText] = useState('');
    const [loading, setLoading] = useState(false);
    const [file, setFile] = useState<File | null>();
    const [quizLoading, setQuizLoading] = useState(false);
    const [checkoutLoading, setCheckoutLoading] = useState(false);
    const [quizData, setQuizData] = useState<QuizQuestion[]>([])
    const [quizDataPopUp, setQuizDataPopUp] = useState(false)
    const [purchasePopUp, setPurchasePopUp] = useState(false)
    const [editIndex, setEditIndex] = useState(null);
    const [openSideBar, setOpenSideBar] = useState(false);


    // New 
    const [activeText, setActiveText] = useState<'text-input' | 'pdf-upload'>('text-input')

    const { state, dispatch, Logout } = useContext(ContextApi)
    const {
        register,
        handleSubmit,
        reset,
        setValue,
        setError,
        formState: {
            errors,
            isSubmitting
        },
    } = useForm<IGenerateQuizSchema>({
        resolver: zodResolver(generateQuizSchema)
    })

    const uploadPDF = (e: ChangeEvent<HTMLInputElement>) => {
        const file = e?.target?.files![0]
        if (!file) return
        console.log(file.type);

        if (file.type !== 'application/pdf') {
            alert('Please Upload a PDF file')
            return
        }
        // setPdfText('')
        let fr = new FileReader()
        fr.readAsDataURL(file)
        fr.onload = () => {
            setFile(file)
            setError('content', { message: '' })
            extractText(fr.result)
        }
    }

    async function extractText(url: any) {
        setLoading(true)
        let alltext: any[] = []
        try {
            // @ts-ignore
            let pdf = await pdfjsLib.getDocument(url).promise; // Get the PDF document without password

            let pages = pdf.numPages; // Get the total number of pages in the PDF
            for (let i = 1; i <= pages; i++) {
                let page = await pdf.getPage(i); // Get the page object for each page
                let txt = await page.getTextContent(); // Get the text content of the page
                // console.log((await page.getTextContent()).styles);
                let text = txt.items.map((s: any) => s.str).join(""); // Concatenate the text items into a single string
                alltext.push(text); // Add the extracted text to the array
            }
            console.log(alltext);
            setValue('content', alltext.map((page) => `${page}\n\n`).join(' '))
            setPdfText(alltext.map((page) => `${page}\n\n`).join(' '))

        } catch (err: any) {
            alert(err.message);
        }
        finally {
            setLoading(false)
        }
    }



    async function GenerateQuiz(config_data: IGenerateQuizSchema) {
        console.log(config_data);
        try {
            setQuizLoading(true)
            const res = await fetch('/api/chat', {
                method: 'POST',
                body: JSON.stringify({
                    content: config_data.content,
                    type: config_data.type,
                    // count: config_data.count,
                    difficulty: config_data.difficulty
                })
            })
            if (res.status === 429) {
                dispatch({ type: 'TOGGLE_CHECKOUT_POPUP', payload: true })
                // setPurchasePopUp(true)
                return
            }
            let { data }: { data: { questions: QuizQuestion[] } } = await res.json()
            console.log(data);
            data.questions = data.questions.map((item) => ({ ...item, correct: item.options[0] }))
            setQuizData(data.questions)
            setOpenSideBar(false)
        }
        catch (err) {
            console.log(err);
        }
        finally {
            setQuizLoading(false)
        }
    }


    function addNewlineAfter5Words(inputString: any) {
        inputString = inputString.split('\n')
        for (let i = 0; i < inputString.length; i++) {
            let innerText = inputString[i].split('')
            for (let j = 0; j < innerText.length; j++) {
                if (j % 89 === 0 && j !== 0) {
                    for (let k = 1; k < 30; k++) {
                        if (innerText[j + k] === ' ') {
                            innerText.splice(j + k, 0, '\n')
                            break;
                        }
                    }
                }
            }
            inputString[i] = innerText.join('')
        }
        return inputString.join('\n');
    }


    // async function GenerateAndDownloadPDF(data: string) {
    //     const pdfDoc = await PDFDocument.create()
    //     const timesRomanFont = await pdfDoc.embedFont(StandardFonts.TimesRoman)
    //     const page = pdfDoc.addPage([600, 1200])
    //     const { width, height } = page.getSize()
    //     const fontSize = 12
    //     page.drawText(addNewlineAfter5Words(data), {
    //         x: 30,
    //         y: height - 3 * fontSize,
    //         size: fontSize,
    //         font: timesRomanFont,
    //         color: rgb(0, 0, 0),
    //     })
    //     const pdfBytes = await pdfDoc.save()

    //     console.log(data);
    //     const file = new Blob([pdfBytes], { type: 'application/pdf' });
    //     saveAs(file, 'quiz-file.pdf');
    // }


    // const generatePDF = () => {
    //     const doc = new jsPDF();
    //     let currentHeight = 10; // Initial Y position to start printing the quiz

    //     quizData.forEach((question, index) => {
    //         // Check if there's enough space for the next question or need a new page
    //         if (currentHeight > 280) {
    //             doc.addPage();
    //             currentHeight = 10; // Reset Y position for the new page
    //         }

    //         doc.setFontSize(12);
    //         doc.text(`${index + 1}. ${question.question}`, 20, currentHeight);
    //         currentHeight += 6; // Increment Y position for options

    //         question.options.forEach((option, optionIndex) => {
    //             const label = String.fromCharCode(97 + optionIndex); // Convert 0, 1, 2, 3 to a, b, c, d
    //             doc.text(`    ${label}) ${option}`, 20, currentHeight);
    //             currentHeight += 6; // Increment Y position for next option or question
    //         });

    //         // Display correct answer
    //         const correctOptionIndex = question.options.indexOf(question.correct);
    //         const correctLabel = String.fromCharCode(97 + correctOptionIndex);
    //         doc.text(`Correct answer: ${correctLabel}) ${question.correct}`, 20, currentHeight);
    //         currentHeight += 10; // Increment Y position for the next question
    //     });

    //     doc.save("quiz.pdf");
    // };

    const generatePDF = () => {
        const doc = new jsPDF();
        let currentHeight = 10; // Initial Y position
        const pageWidth = doc.internal.pageSize.getWidth();
        const marginLeft = 20;
        const marginRight = 20;
        const maxWidth = pageWidth - marginLeft - marginRight; // Calculate the maximum width of the text

        doc.setFontSize(10); // Set the font size to 10px for the entire document

        const addTextWithWrap = (text: string, indent: number = 0, spaceAfter: number = 6) => {
            const lines = doc.splitTextToSize(text, maxWidth - indent);
            lines.forEach((line: any) => {
                if (currentHeight > 280) { // Check if a new page is needed
                    doc.addPage();
                    currentHeight = 10; // Reset Y position for the new page
                    doc.setFontSize(10); // Ensure the font size is reset for the new page
                }
                doc.text(line, marginLeft + indent, currentHeight);
                currentHeight += 5; // Adjust for the next line
            });
            currentHeight += spaceAfter; // Additional space after the text block
        };

        quizData.forEach((question, index) => {
            // Question
            addTextWithWrap(`${index + 1}. ${question.question}`, 0, 2); // Increased space after the question

            // Options
            question.options.forEach((option, optionIndex) => {
                const label = String.fromCharCode(97 + optionIndex); // Convert 0, 1, 2, 3 to a, b, c, d
                addTextWithWrap(`${label}) ${option}`, 5, 1); // Maintain default space after options
            });

            // Correct Answer
            const correctOptionIndex = question.options.indexOf(question.correct);
            const correctLabel = String.fromCharCode(97 + correctOptionIndex);
            addTextWithWrap(`Correct answer: ${correctLabel}) ${question.correct}`, 0, 7); // Increased space before the next question
        });

        doc.save("quiz.pdf");
    };


    async function CheckOut() {
        try {
            setCheckoutLoading(true)
            const res = await fetch("/api/payment", {
                method: "POST",
                body: JSON.stringify({}),
                headers: {
                    "Content-Type": "application/json"
                }
            });
            const data = await res.json()
            console.log(data)
            if (data.url) {
                window.location.assign(data.url)
            }
        }
        catch (err: any) {
            console.log(err);
        }
        finally {
            setCheckoutLoading(false)
        }
    }


    const handleActiveTab = (val: any) => {
        setActiveText(val)
        setValue('content', '')
        setError('content', { message: '' })
        setPdfText('')
        setFile(null)

    }


    const deleteItemAtIndex = (index: number) => {
        setQuizData(currentData => {
            // Option 1: Using filter for immutability
            return currentData.filter((item, idx) => idx !== index);

            // Option 2: Using slice for immutability (uncomment to use)
            // return [...currentData.slice(0, index), ...currentData.slice(index + 1)];
        });
        setEditIndex(null)
    }


    const toggleEdit = (index: any) => {
        setEditIndex(prevIndex => prevIndex === index ? null : index);
    };

    const handleQuestionChange = (e: ChangeEvent<HTMLInputElement>, index: number) => {
        const updatedQuizData = quizData.map((item, idx) => idx === index ? { ...item, question: e.target.value } : item);
        setQuizData(updatedQuizData);
    };

    const handleOptionChange = (e: ChangeEvent<HTMLInputElement>, index: number, optionIndex: number) => {
        const updatedQuizData = quizData.map((item, idx) => {
            if (idx === index) {
                const updatedOptions = item.options.map((opt, i) => i === optionIndex ? e.target.value : opt);
                return { ...item, options: updatedOptions };
            }
            return item;
        });
        setQuizData(updatedQuizData);
    };

    const handleCorrectAnswerChange = (e: ChangeEvent<HTMLSelectElement>, index: number) => {
        const updatedQuizData = quizData.map((item, idx) => idx === index ? { ...item, correct: e.target.value } : item);
        setQuizData(updatedQuizData);
    };


    return (
        <div className='bg-[#f5f5f5] w-full min-h-screen'>
            <Script src="https://npmcdn.com/pdfjs-dist@3.11.174/build/pdf.js" ></Script>

            {/* {
                quizDataPopUp &&
                <div className='fixed top-0 left-0 w-screen h-screen flex justify-center items-center bg-[rgba(0,0,0,0.3)] backdrop-blur-sm'>
                    <div className='w-[90%] md:w-[700px] h-[90vh] flex flex-col bg-white px-5 pt-5'>
                        <textarea name="" id="" value={quizData} onChange={(e) => setQuizData(e.target.value)} cols={30} rows={10} className='text-sm md:text-base outline-none flex-grow'></textarea>
                        <div className='py-5 flex gap-5 border-t'>
                            <button className='py-2 px-5 tracking-wider text-sm text-white font-semibold border-2 border-primary bg-primary rounded-lg' onClick={() => GenerateAndDownloadPDF(quizData)}>Download PDF</button>
                            <button className='py-2 px-5 tracking-wider text-sm font-semibold border-2 border-primary rounded-lg' onClick={() => setQuizDataPopUp(false)}>Close</button>
                        </div>
                    </div>
                </div >
            } */}
            {
                state.checkOutPopUp &&
                <div className='fixed top-0 left-0 z-30 w-screen h-screen flex justify-center items-center bg-[rgba(0,0,0,0.3)] backdrop-blur-sm'>
                    <div className='w-[90%] md:w-[500px] flex flex-col bg-white px-5 pt-5'>
                        <div className='mb-10'>
                            <h1 className='text-2xl font-extrabold text-zinc-800'>Monthly Plan</h1>
                            <h1 className='text-lg font-extrabold text-zinc-800 mt-10'><span className='text-4xl'>$2.99</span> / Month</h1>
                            <button onClick={() => checkoutLoading ? false : CheckOut()} disabled={checkoutLoading} className='font-extrabold text-white [word-spacing:5px] flex justify-center items-center h-[50px] w-[250px] sm:w-[300px] rounded-lg bg-primary mt-10'>{checkoutLoading ? <Loader height='h-4' width='w-4' /> : 'Proceed to Payment'} </button>
                        </div>
                        <div className='py-5 flex gap-5 border-t'>
                            <button className='py-2 px-5 tracking-wider text-sm font-semibold border-2 border-primary rounded-lg' onClick={() => dispatch({ type: 'TOGGLE_CHECKOUT_POPUP', payload: false })}>Close</button>
                        </div>
                    </div>
                </div >
            }


            {/* Old UI  */}

            {/* <div>
                <div className='w-[90%] lg:w-[800px] m-auto rounded-lg p-5'>
                    <label htmlFor="pdf" className='w-full border border-dashed border-zinc-600 cursor-pointer rounded-lg h-[70px] bg-zinc-200 flex justify-center items-center'>
                        <div className='flex gap-5 items-center'>
                            {
                                !loading ?
                                    <>
                                        <h1 className='text-lg font-extrabold text-zinc-800'>Upload PDF</h1>
                                        <AiOutlineCloudUpload className='text-4xl text-primary' />
                                    </>
                                    :
                                    <h1 className='text-lg font-extrabold text-zinc-800'>Uploading ...</h1>
                            }
                        </div>
                        <input hidden onChange={uploadPDF} type="file" name="pdf" id="pdf" />
                    </label>
                    <form onSubmit={handleSubmit(GenerateQuiz)}>
                        <div className='w-full h-[280px] text-sm p-3 rounded-3xl mt-5 bg-white shadow-[0_0_20px_rgba(0,0,0,0.1)]'>
                            {
                                !pdfText ?
                                    <div className='w-full h-full flex justify-center items-center'>
                                        <h1 className='text-lg text-zinc-800 font-extrabold [word-spacing:3px]'>No PDF Uploaded</h1>
                                    </div>
                                    :
                                    <textarea {...register("content")} className='w-full h-full resize-none outline-none'></textarea>
                            }
                        </div>
                        {
                            errors.content && <p className='text-red-500 text-sm mt-2'>{file ? errors.content.message : 'Upload a PDF file'}</p>
                        }
                        <div className='mt-5 grid grid-cols-1 md:grid-cols-3 gap-5 mb-5'>
                            <div>
                                <label htmlFor="type" className='text-sm font-bold text-[#26292E]'>Select Quiz Type</label>
                                <select id="type" {...register("type")} className={`text-sm outline-none w-full py-3 px-5 rounded-xl bg-white shadow-[0_0_20px_rgba(0,0,0,0.1)] mt-1`}>
                                    {
                                        type.map((item, index) => <option value={item} key={index}>{item}</option>)
                                    }
                                </select>
                                {
                                    errors.type && <p className='text-red-500 text-sm'>{errors.type.message}</p>
                                }
                            </div>
                            <div>
                                <label htmlFor="count" className='text-sm font-bold text-[#26292E]'>Question Count</label>
                                <select id="count" {...register("count")} className={`text-sm outline-none w-full py-3 px-5 rounded-xl bg-white shadow-[0_0_20px_rgba(0,0,0,0.1)] mt-1`}>
                                    {
                                        count.map((item, index) => <option value={item} key={index}>{item}</option>)
                                    }
                                </select>
                                {
                                    errors.count && <p className='text-red-500 text-sm'>{errors.count.message}</p>
                                }
                            </div>
                            <div>
                                <label htmlFor="type" className='text-sm font-bold text-[#26292E]'>Select Difficulty Level</label>
                                <select id="type" {...register("difficulty")} className={`text-sm outline-none w-full py-3 px-5 rounded-xl bg-white shadow-[0_0_20px_rgba(0,0,0,0.1)] mt-1`}>
                                    {
                                        difficulty.map((item, index) => <option value={item} key={index}>{item}</option>)
                                    }
                                </select>
                                {
                                    errors.difficulty && <p className='text-red-500 text-sm'>{errors.difficulty.message}</p>
                                }
                            </div>
                        </div>
                        <button type={quizLoading ? 'button' : 'submit'} className='w-full py-3 bg-primary rounded-lg text-white font-semibold text-center'>{quizLoading ? 'Generating Quiz ...' : 'Generate Quiz'}</button>
                        {
                            quizData &&
                            <p className='text-sm md:text-base text-zinc-800 mt-3'>Quiz generated successfully. <span className='text-primary underline cursor-pointer' onClick={() => setQuizDataPopUp(true)}>Click Here</span> to view Quiz</p>
                        }
                    </form>
                </div>
            </div> */}




            {/* New UI */}


            {/* Responsive Side Bar */}
            {/* Responsive Side Bar */}
            {/* Responsive Side Bar */}


            <div className={`h-full w-[90%] md:hidden overflow-y-auto ${openSideBar ? 'left-0 px-5' : '-left-[90%] px-0'} transition-all absolute bg-white pb-10 shadow-2xl`}>
                <div onClick={() => setOpenSideBar(false)} className='absolute top-4 right-4 font-bold'>
                    X
                </div>
                <form onSubmit={handleSubmit(GenerateQuiz)}>
                    <div className='py-10'>
                        <Image src={'/logo.png'} alt='logo' width={160} height={43} className='w-[100px] md:w-[140px]' />
                    </div>
                    <div className="">
                        <h1 className='text-2xl font-extrabold text-zinc-900 tracking-tighter [word-spacing:5px]'>Create New Quiz</h1>
                        <div className='bg-gray-50 border border-zinc-200 rounded-md p-1 flex gap-3 mt-5'>
                            <div onClick={() => handleActiveTab('text-input')} className={`w-1/2 flex justify-center cursor-pointer py-[6px] font-semibold ${activeText === 'text-input' ? 'bg-white border border-zinc-200 text-primary' : 'text-zinc-500 border border-transparent'} rounded-[4px]`}>Text Input</div>
                            <div onClick={() => handleActiveTab('pdf-upload')} className={`w-1/2 flex justify-center cursor-pointer py-[6px] font-semibold ${activeText === 'pdf-upload' ? 'bg-white border border-zinc-200 text-primary' : 'text-zinc-500 border border-transparent'} rounded-[4px]`}>PDF Upload</div>
                        </div>
                    </div>
                    <div className='mt-10'>
                        {
                            activeText === 'text-input' ?
                                <h1 className='text-zinc-900 text-lg font-bold'>Enter Text</h1>
                                :
                                <h1 className='text-zinc-900 text-lg font-bold'>Upload Document</h1>
                        }
                        <div className='mt-3'>
                            {
                                activeText === 'text-input' ?
                                    <textarea {...register("content")} cols={30} rows={6} placeholder='Enter text' className='w-full text-sm p-3 rounded-lg border border-zinc-200 resize-none'></textarea>
                                    :
                                    <label htmlFor="pdf" className='w-full border border-dashed border-zinc-200 cursor-pointer rounded-lg h-[100px] flex justify-center items-center'>
                                        <div className='flex gap-5 items-center'>
                                            {
                                                loading ?
                                                    <h1 className='text-base font-extrabold text-zinc-800'>Uploading ...</h1>
                                                    :
                                                    <div className='flex flex-col items-center'>
                                                        <div className='flex gap-2 items-center'>
                                                            <h1 className='text-base font-extrabold text-zinc-800'>Upload PDF</h1>
                                                            <AiOutlineCloudUpload className='text-3xl text-primary' />
                                                        </div>
                                                        {
                                                            file &&
                                                            <h1 className='text-xs font-extrabold text-zinc-500 mt-2'>{file.name}</h1>
                                                        }
                                                    </div>
                                            }
                                        </div>
                                        <input hidden onChange={uploadPDF} type="file" name="pdf" id="pdf" />
                                    </label>
                            }
                            {
                                errors.content && errors.content?.message && <p className='text-red-500 text-sm mt-2'>{activeText === 'pdf-upload' ? 'Upload a file' : errors.content.message}</p>
                            }
                        </div>
                    </div>
                    <div className='w-full mt-10 grid grid-cols-1 md:grid-cols-2 gap-5'>
                        <div>
                            <label htmlFor="type" className='text-sm font-bold text-[#26292E]'>Select Quiz Type</label>
                            <select id="type" {...register("type")} className={`text-sm outline-none w-full py-2 px-5 rounded-md bg-white border border-zinc-200 mt-1`}>
                                {
                                    type.map((item, index) => <option value={item} key={index}>{item}</option>)
                                }
                            </select>
                            {
                                errors.type && <p className='text-red-500 text-sm'>{errors.type.message}</p>
                            }
                        </div>
                        {/* <div>
                            <label htmlFor="count" className='text-sm font-bold text-[#26292E]'>Question Count</label>
                            <select id="count" {...register("count")} className={`text-sm outline-none w-full py-2 px-5 rounded-md bg-white border border-zinc-200 mt-1`}>
                                {
                                    count.map((item, index) => <option value={item} key={index}>{item}</option>)
                                }
                            </select>
                            {
                                errors.count && <p className='text-red-500 text-sm'>{errors.count.message}</p>
                            }
                        </div> */}
                        <div>
                            <label htmlFor="type" className='text-sm font-bold text-[#26292E]'>Select Difficulty Level</label>
                            <select id="type" {...register("difficulty")} className={`text-sm outline-none w-full py-2 px-5 rounded-md bg-white border border-zinc-200 mt-1`}>
                                {
                                    difficulty.map((item, index) => <option value={item} key={index}>{item}</option>)
                                }
                            </select>
                            {
                                errors.difficulty && <p className='text-red-500 text-sm'>{errors.difficulty.message}</p>
                            }
                        </div>
                    </div>
                    <button type={quizLoading ? 'button' : 'submit'} className='w-full text-sm py-3 mt-10 bg-primary rounded-lg text-white font-bold text-center shadow-[0_0_4px_rgba(0,0,0,0.3)]'>{quizLoading ? 'Generating ...' : 'Generate'}</button>
                </form>
                <div className='mt-14 border rounded-lg py-2 px-2'>
                    {
                        state.loading ? <li>loading...</li>
                            :
                            state.userDetails ?
                                <div className='flex gap-3 items-center'>
                                    <div className='w-[45px] h-[45px] shrink-0 text-white text-sm font-bold uppercase rounded-full bg-orange-500 flex justify-center items-center'>
                                        {state.userDetails.name[0]}
                                    </div>
                                    <div className='w-full flex flex-col items-start gap-2'>
                                        <p className='text-zinc-900 font-semibold text-xs [word-break:break-all;]'>{state.userDetails.email}</p>
                                        <div className='w-full flex justify-between'>
                                            {
                                                state.userDetails.purchased ?
                                                    <button className='text-xs font-bold bg-green-300 py-2 px-2 rounded-lg'>Premium</button>
                                                    :
                                                    <div className='flex gap-2'>
                                                        <button className='text-xs font-bold bg-red-200 py-2 px-2 rounded-lg'>Free</button>
                                                        <button onClick={() => dispatch({ type: 'TOGGLE_CHECKOUT_POPUP', payload: true })} className='text-xs font-bold bg-gray-300 py-2 px-2 rounded-lg'>Buy</button>
                                                    </div>}
                                            <button onClick={Logout} className='text-xs font-bold bg-red-300 py-2 px-2 rounded-lg flex gap-1'><FiLogOut className='text-sm' /> Logout</button>
                                        </div>
                                    </div>
                                </div>
                                : null
                    }
                </div>
            </div>
            <div className='w-full flex h-screen'>
                <div className='h-full overflow-y-auto w-[350px] lg:w-[450px] shrink-0 hidden md:block bg-white px-5 pb-10'>
                    <form onSubmit={handleSubmit(GenerateQuiz)}>
                        <div className='py-10'>
                            <Image src={'/logo.png'} alt='logo' width={160} height={43} className='w-[100px] md:w-[140px]' />
                        </div>
                        <div className="">
                            <h1 className='text-2xl font-extrabold text-zinc-900 tracking-tighter [word-spacing:5px]'>Create New Quiz</h1>
                            <div className='bg-gray-50 border border-zinc-200 rounded-md p-1 flex gap-3 mt-5'>
                                <div onClick={() => handleActiveTab('text-input')} className={`w-1/2 flex justify-center cursor-pointer py-[6px] font-semibold ${activeText === 'text-input' ? 'bg-white border border-zinc-200 text-primary' : 'text-zinc-500 border border-transparent'} rounded-[4px]`}>Text Input</div>
                                <div onClick={() => handleActiveTab('pdf-upload')} className={`w-1/2 flex justify-center cursor-pointer py-[6px] font-semibold ${activeText === 'pdf-upload' ? 'bg-white border border-zinc-200 text-primary' : 'text-zinc-500 border border-transparent'} rounded-[4px]`}>PDF Upload</div>
                            </div>
                        </div>
                        <div className='mt-10'>
                            {
                                activeText === 'text-input' ?
                                    <h1 className='text-zinc-900 text-lg font-bold'>Enter Text</h1>
                                    :
                                    <h1 className='text-zinc-900 text-lg font-bold'>Upload Document</h1>
                            }
                            <div className='mt-3'>
                                {
                                    activeText === 'text-input' ?
                                        <textarea {...register("content")} cols={30} rows={6} placeholder='Enter text' className='w-full text-sm p-3 rounded-lg border border-zinc-200 resize-none'></textarea>
                                        :
                                        <label htmlFor="pdf" className='w-full border border-dashed border-zinc-200 cursor-pointer rounded-lg h-[100px] flex justify-center items-center'>
                                            <div className='flex gap-5 items-center'>
                                                {
                                                    loading ?
                                                        <h1 className='text-base font-extrabold text-zinc-800'>Uploading ...</h1>
                                                        :
                                                        <div className='flex flex-col items-center'>
                                                            <div className='flex gap-2 items-center'>
                                                                <h1 className='text-base font-extrabold text-zinc-800'>Upload PDF</h1>
                                                                <AiOutlineCloudUpload className='text-3xl text-primary' />
                                                            </div>
                                                            {
                                                                file &&
                                                                <h1 className='text-xs font-extrabold text-zinc-500 mt-2'>{file.name}</h1>
                                                            }
                                                        </div>
                                                }
                                            </div>
                                            <input hidden onChange={uploadPDF} type="file" name="pdf" id="pdf" />
                                        </label>
                                }
                                {
                                    errors.content && errors.content?.message && <p className='text-red-500 text-sm mt-2'>{activeText === 'pdf-upload' ? 'Upload a file' : errors.content.message}</p>
                                }
                            </div>
                        </div>
                        <div className='w-full mt-10 grid grid-cols-1 md:grid-cols-2 gap-5'>
                            <div>
                                <label htmlFor="type" className='text-sm font-bold text-[#26292E]'>Select Quiz Type</label>
                                <select id="type" {...register("type")} className={`text-sm outline-none w-full py-2 px-5 rounded-md bg-white border border-zinc-200 mt-1`}>
                                    {
                                        type.map((item, index) => <option value={item} key={index}>{item}</option>)
                                    }
                                </select>
                                {
                                    errors.type && <p className='text-red-500 text-sm'>{errors.type.message}</p>
                                }
                            </div>
                            {/* <div>
                                <label htmlFor="count" className='text-sm font-bold text-[#26292E]'>Question Count</label>
                                <select id="count" {...register("count")} className={`text-sm outline-none w-full py-2 px-5 rounded-md bg-white border border-zinc-200 mt-1`}>
                                    {
                                        count.map((item, index) => <option value={item} key={index}>{item}</option>)
                                    }
                                </select>
                                {
                                    errors.count && <p className='text-red-500 text-sm'>{errors.count.message}</p>
                                }
                            </div> */}
                            <div>
                                <label htmlFor="type" className='text-sm font-bold text-[#26292E]'>Select Difficulty Level</label>
                                <select id="type" {...register("difficulty")} className={`text-sm outline-none w-full py-2 px-5 rounded-md bg-white border border-zinc-200 mt-1`}>
                                    {
                                        difficulty.map((item, index) => <option value={item} key={index}>{item}</option>)
                                    }
                                </select>
                                {
                                    errors.difficulty && <p className='text-red-500 text-sm'>{errors.difficulty.message}</p>
                                }
                            </div>
                        </div>
                        <button type={quizLoading ? 'button' : 'submit'} className='w-full text-sm py-3 mt-10 bg-primary rounded-lg text-white font-bold text-center shadow-[0_0_4px_rgba(0,0,0,0.3)]'>{quizLoading ? 'Generating ...' : 'Generate'}</button>
                    </form>
                    <div className='mt-14 border rounded-lg py-2 px-2'>
                        {
                            state.loading ? <li>loading...</li>
                                :
                                state.userDetails ?
                                    <div className='flex gap-3 items-center'>
                                        <div className='w-[45px] h-[45px] shrink-0 text-white text-sm font-bold uppercase rounded-full bg-orange-500 flex justify-center items-center'>
                                            {state.userDetails.name[0]}
                                        </div>
                                        <div className='w-full flex flex-col items-start gap-2'>
                                            <p className='text-zinc-900 font-semibold text-xs [word-break:break-all;]'>{state.userDetails.email}</p>
                                            <div className='w-full flex justify-between'>
                                                {
                                                    state.userDetails.purchased ?
                                                        <button className='text-xs font-bold bg-green-300 py-2 px-2 rounded-lg'>Premium</button>
                                                        :
                                                        <div className='flex gap-2'>
                                                            <button className='text-xs font-bold bg-red-200 py-2 px-2 rounded-lg'>Free</button>
                                                            <button onClick={() => dispatch({ type: 'TOGGLE_CHECKOUT_POPUP', payload: true })} className='text-xs font-bold bg-gray-300 py-2 px-2 rounded-lg'>Buy</button>
                                                        </div>
                                                }
                                                <button onClick={Logout} className='text-xs font-bold bg-red-300 py-2 px-2 rounded-lg flex gap-1'><FiLogOut className='text-sm' /> Logout</button>
                                            </div>
                                        </div>
                                    </div>
                                    : null
                        }
                    </div>
                </div>
                <div className='flex-grow h-full overflow-y-auto'>
                    <div onClick={() => setOpenSideBar(true)} className='w-[90%] m-auto py-7 block md:hidden'><IoMenu className='text-2xl font-bold' /></div>
                    <div className='w-full h-full flex justify-center items-start mt-5 md:pt-20 pb-10'>
                        {
                            !quizData.length ?
                                <>
                                    <div className='w-[90%] lg:w-[550px] bg-white py-7 px-10 flex flex-col gap-5 rounded-3xl shadow-[0_0_20px_rgba(0,0,0,0.1)]'>
                                        <div className="flex gap-3">
                                            <h1 className='text-2xl text-zinc-900 font-extrabold'>01</h1>
                                            <div className=''>
                                                <h4 className='text-zinc-900 text-base font-bold'>Upload your notes</h4>
                                                <p className='text-zinc-900 text-base'>Begin by uploading your lecture slides, notes, or other study materials to our platform</p>
                                            </div>
                                        </div>
                                        <div className="flex gap-3">
                                            <h1 className='text-2xl text-zinc-900 font-extrabold'>02</h1>
                                            <div className=''>
                                                <h4 className='text-zinc-900 text-base font-bold'>Quiz generation</h4>
                                                <p className='text-zinc-900 text-base'>Our advanced algorithms will analyze your notes to identify key concepts and generate relevant questions with answer keys</p>
                                            </div>
                                        </div>
                                        <div className="flex gap-3">
                                            <h1 className='text-2xl text-zinc-900 font-extrabold'>03</h1>
                                            <div className=''>
                                                <h4 className='text-zinc-900 text-base font-bold'>Practice, review, ace</h4>
                                                <p className='text-zinc-900 text-base'>Use the generated questions to test your knowledge, reinforce your learning, and improve your understanding</p>
                                            </div>
                                        </div>
                                    </div>
                                </>
                                :

                                <div className='w-[90%] lg:w-[550px]'>
                                    <h1 className='text-4xl text-zinc-900 font-extrabold'>Your quiz is ready!</h1>
                                    <button onClick={generatePDF} className='w-full text-sm py-3 mt-10 bg-primary rounded-lg text-white font-bold text-center shadow-[0_0_4px_rgba(0,0,0,0.3)]'>Download Quiz</button>
                                    {/* <div className='flex flex-col gap-5 mt-5'>
                                        {
                                            quizData.map((val, index) => {
                                                return (
                                                    <div key={index} className='w-full bg-white py-7 px-7 rounded-3xl shadow-[0_0_20px_rgba(0,0,0,0.1)]'>
                                                        <h4 className='text-zinc-900 text-base font-bold'>{index + 1}. {val.question}</h4>
                                                        <div className='flex flex-col gap-3 mt-5'>
                                                            {
                                                                val.options.map((option, i) => {
                                                                    return (
                                                                        <div key={i} className='bg-gray-50 border border-zinc-200 rounded-md py-[6px] px-3'>
                                                                            {option}
                                                                        </div>
                                                                    )
                                                                })
                                                            }
                                                        </div>
                                                        <div className='mt-5'>
                                                            <h4 className='text-zinc-900 text-base font-bold'>Answer</h4>
                                                            <div className='bg-gray-50 border border-zinc-200 rounded-md py-[6px] px-3 mt-3'>
                                                                {val.correct}
                                                            </div>
                                                        </div>
                                                        <div className='flex justify-end mt-7'>
                                                            <TbTrash onClick={() => deleteItemAtIndex(index)} className='text-3xl text-red-600 cursor-pointer' />
                                                        </div>
                                                    </div>
                                                )
                                            })
                                        }

                                    </div> */}
                                    <div className='flex flex-col gap-5 mt-5'>
                                        {quizData.map((val, index) => (
                                            <div key={index} className='w-full bg-white py-7 px-7 rounded-3xl shadow-[0_0_20px_rgba(0,0,0,0.1)]'>
                                                <div className='text-zinc-900 text-base font-bold flex items-center'>
                                                    {index + 1}.
                                                    {editIndex === index ? (
                                                        <input type="text" value={val.question} onChange={(e) => handleQuestionChange(e, index)} className="py-1 px-2 bg-green-50 border flex-grow" />
                                                    ) : (
                                                        ` ${val.question}`
                                                    )}
                                                </div>
                                                <div className='flex flex-col gap-3 mt-5'>
                                                    {val.options.map((option, optionIndex) => (
                                                        <div key={optionIndex} className='bg-gray-50 border border-zinc-200 rounded-md py-[6px] px-3'>
                                                            {editIndex === index ? (
                                                                <input className='w-full bg-green-50 py-1 px-2 border' type="text" value={option} onChange={(e) => handleOptionChange(e, index, optionIndex)} />
                                                            ) : (
                                                                option
                                                            )}
                                                        </div>
                                                    ))}
                                                </div>
                                                <div className='mt-5'>
                                                    <h4 className='text-zinc-900 text-base font-bold'>Answer</h4>
                                                    <select defaultValue={val.correct} onChange={(e) => handleCorrectAnswerChange(e, index)} className='w-full bg-gray-50 border border-zinc-200 rounded-md py-[6px] px-3 mt-3'>
                                                        {/* <option value="" disabled>Select Correct Answer</option> */}
                                                        {
                                                            val.options.map((item, i) => {
                                                                return (
                                                                    <option key={i} value={item}>{item}</option>
                                                                )
                                                            })
                                                        }
                                                    </select>
                                                    {/* {editIndex === index ? (
                                                        <input type="text" value={val.correct} onChange={(e) => handleCorrectAnswerChange(e, index)} className='w-full bg-green-50 border py-[6px] px-3 mt-3' />
                                                    ) : (
                                                        <div className='bg-gray-50 border border-zinc-200 rounded-md py-[6px] px-3 mt-3'>{val.correct}</div>
                                                    )} */}
                                                </div>
                                                <div className='flex justify-end gap-3 mt-7'>
                                                    <button onClick={() => toggleEdit(index)}>{editIndex === index ? 'Save' : 'Edit'}</button>
                                                    <TbTrash onClick={() => deleteItemAtIndex(index)} className='text-3xl text-red-600 cursor-pointer' />
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                        }


                    </div>
                </div>
            </div>

        </div>

    );
}

export default Dashboard