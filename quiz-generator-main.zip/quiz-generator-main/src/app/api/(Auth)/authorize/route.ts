import { NextRequest, NextResponse } from "next/server";
import jwt from 'jsonwebtoken'

export async function POST(request: NextRequest) {
    console.log("JWT");
    const body = await request.json()
    let { token }: { token: string } = body;
    try {
        let verifiedJwt = jwt.verify(token, process.env.JWT_SECRET!);
        return NextResponse.json({ verifiedJwt });
    } catch (err) {
        return NextResponse.json({ status: 'error' })
    }
}
