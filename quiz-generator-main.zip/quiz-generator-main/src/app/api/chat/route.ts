import { connect } from "@/db";
import User from "@/db/models/users";
import { IGenerateQuizSchema, generateQuizSchema } from "@/lib/zodSchema";
import { NextRequest, NextResponse } from "next/server";
import OpenAI from "openai";

export const maxDuration = 300

export const POST = async (request: NextRequest) => {

    const openai = new OpenAI();

    try {
        await connect()
        const verifiedJwt = JSON.parse(request.headers.get('verifiedJwt')!)
        let user = await User.findOne({ _id: verifiedJwt.id })
        if (user.freeTurns <= 0 && !user.purchased) {
            return NextResponse.json({ status: 'error', message: 'Free trail ended' }, { status: 429 })
        }

        const body: IGenerateQuizSchema = await request.json()
        let words = body.content.trim().split(/\s+/);
        console.log('length ==>> ', words.length);
        
        let result = generateQuizSchema.safeParse(body)
        if (!result.success) {
            let zodErrors = {}
            result.error.issues.forEach((issue) => {
                zodErrors = { ...zodErrors, [issue.path[0]]: issue.message }
            })
            return NextResponse.json({ errors: zodErrors, status: 'error' }, { status: 400 })
        }

        const type = body.type === 'MCQs' ? 'MCQs (Multiple Choice Questions)' : body.type
        const finalPrompt = `
Please generate a quiz that consists of ${body.type} questions.
The difficulty level of questions should be ${body.difficulty}.
The numbers of words in text are ${words.length}.
The number of questions must based on text words length , if the number of words in text are less than 1000 then generate 5 to 10 questions and if the number of words are greater than 1000 then generate 12 to 20 questions. and question must be of type ${body.type}.
Question format should be like this:
{

    "questions" : [
        {
            questions: Question 1?
            options:['option1','option2','option3','option4'],
            correct: Answer
        },
        {
            questions: Question 2?
            options:['option1','option2','option3','option4'],
            correct: Answer
        }
        ....
        ....
        ....
    ]
}

Now, based on the following text, generate the questions for the quiz in json format:

///${body.content}///
`

        // Q{Question number}: Question ?
        // a) Option 1
        // b) Option 2
        // c) Option 3
        // d) Option 4
        // Correct Answer: {Option}) Answer
        // ....
        // ....
        // ....

        const data = await openai.chat.completions.create({
            messages: [{ role: "user", content: finalPrompt }],
            model: "gpt-3.5-turbo",
            response_format: { type: 'json_object' }
        });
        // const res = await fetch('https://api.openai.com/v1/completions', {
        //     method: 'POST',
        //     headers: {
        //         Authorization: `Bearer ${process.env.OPENAI_API_KEY}`,
        //         "Content-Type": "application/json"
        //     },
        //     body: JSON.stringify({
        //         model: 'gpt-3.5-turbo',
        //         messages: [{ role: "user", content: finalPrompt }],
        //         // prompt: finalPrompt,
        //         max_tokens: 500,
        //     })
        // })
        // const data = await res.json()

        // if (!data.choices[0].text) {
        //     throw new Error('error')
        // }
        if (!user.purchased) {
            await User.findOneAndUpdate({ _id: verifiedJwt.id }, { freeTurns: user.freeTurns - 1 })
        }
        return NextResponse.json({ status: 'success', data: JSON.parse(data.choices[0].message.content!) })
    }
    catch (err: any) {
        return NextResponse.json({ status: 'error', message: err.message }, { status: 500 })
    }
}




