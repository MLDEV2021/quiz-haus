import { connect } from "@/db";
import User from "@/db/models/users";
import { NextRequest, NextResponse } from "next/server";
import Stripe from "stripe";


const endpointSecret = process.env.ENDPOINT_SECRET!;

// stripe listen --forward-to localhost:3000/api/payment/webhook

export async function POST(request: NextRequest) {
    await connect()
    console.log(process.env.STRIPE_SECRET_KEY)
    const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, { apiVersion: '2023-10-16' })
    const sig = request.headers.get('stripe-signature') || 'unknown';
    const data = await request.text()
    console.log("Signature ==================== >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>", sig)
    // console.log("Data ==================== >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>", JSON.stringify(data))
    console.log("EndPoint ==================== >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>", endpointSecret)
    let event;
    try {
        event = stripe.webhooks.constructEvent(data, sig, endpointSecret);
        console.log("SUCCESSSSSSSSSSSSSS================>>>>>>>>>>")
    } catch (err: any) {
        console.log("ERROR================>>>>>>>>>>", err)
        return NextResponse.json({ message: `Webhook Error =======>>>>>>>>>> : ${err.message}` }, { status: 500 })
    }

    if (event.type === 'checkout.session.completed') {
        try {

            const data: any = event.data.object;
            const customer: any = await stripe.customers.retrieve(data.customer)
            const user = await User.findOneAndUpdate({ _id: customer.metadata.user_id }, { purchased: true })
            console.log("Data ===>>>>>", data);
            console.log("Customer ===>>>>>", customer);
        }
        catch (err) {
            console.log("error ========>>>>>>>>>", err)
        }
    }
    return NextResponse.json({ message: "done" })
}