import { NextRequest, NextResponse } from "next/server";
import Stripe from "stripe";



export async function POST(request: NextRequest) {
    try {
        const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, { apiVersion: '2023-10-16' })
        const body = await request.json()
        const verifiedJwt = JSON.parse(request.headers.get('verifiedJwt')!)

        const customer = await stripe.customers.create({
            metadata: {
                user_id: verifiedJwt.id
            }
        });
        const session = await stripe.checkout.sessions.create({
            line_items: [
                {
                    price_data: {
                        currency: 'usd',
                        unit_amount: 299,
                        product_data:{
                            name:'quiz-generator',
                        }
                    },
                    quantity: 1,
                }
            ],
            mode: 'payment',
            payment_method_types: ["card"],
            billing_address_collection: "auto",
            customer: customer.id,
            shipping_address_collection: {
                allowed_countries: ['SG'],
            },
            success_url: `${request.nextUrl.origin}/dashboard`,
            cancel_url: `${request.nextUrl.origin}/failedpayment`
        })
        return NextResponse.json({ url: session.url })
    }
    catch (err) {
        console.log(err)
        return NextResponse.json({ message: "error", err }, { status: 500 })
    }

}