import { NextRequest, NextResponse } from "next/server";

export async function middleware(request: NextRequest) {

    const requestHeaders = new Headers(request.headers);
    const token = request.cookies.get("token")?.value;
    if ((request.nextUrl.pathname === '/login' || request.nextUrl.pathname === '/signup') && token) {
        return NextResponse.redirect(new URL("/dashboard", request.url));
    }
    if (!authRoutes.find((val) => val === request.nextUrl.pathname)) {
        return NextResponse.next()
    }
    if (!token) {
        const response = NextResponse.redirect(new URL("/login", request.url))
        response.cookies.delete("token");
        return response
    }

    try {
        const res = await fetch(request.nextUrl.origin + '/api/authorize', {
            method: 'POST',
            body: JSON.stringify({ token })
        })
        const resData = await res.json()

        if (!resData.verifiedJwt) {
            const response = NextResponse.redirect(new URL("/login", request.url))
            response.cookies.delete("token");
            return response
        }
        requestHeaders.set("verifiedJwt", JSON.stringify(resData.verifiedJwt));
        // console.log("resData ==>> ", resData.verifiedJwt);
        const response = NextResponse.next({
            request: {
                headers: requestHeaders,
            },
        });
        return response;

    }
    catch (err: any) {
        console.log('error ===>>> ', err);
        const response = NextResponse.redirect(new URL("/login", request.url))
        response.cookies.delete("token");
        return response
    }


}


const authRoutes = [
    '/dashboard',
    '/api/whoami',
    '/api/chat',
    '/api/payment'
]